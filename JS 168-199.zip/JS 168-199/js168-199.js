// 168 Многомерные массивы в JavaScript
// Выведите с его помощью элементы с текстом 'l', 'e', 'g' и 'a'.
let arr168 = [
	['a', 'b', 'c'],
	['d', 'e', 'f'],
	['g', 'h', 'i'],
	['j', 'k', 'l'],
];
console.log(arr168[3][2],arr168[1][1],arr168[2][0], arr168[0][0])

// 169 Трехмерный массив в JavaScript
// Обращаясь к каждому элементу массива найдите сумму всех его элементов.
let arr169 = [
	[
		[1, 2],
		[3, 4],
	],
	[
		[5, 6],
		[7, 8],
	],
];
console.log(arr169[0][0][0]+arr169[0][0][1]+arr169[0][1][0]+arr169[0][1][1]+arr169[1][0][0]+arr169[1][0][1]+arr169[1][1][0]+arr169[1][1][1])

// 170 Произвольные массивы в JavaScript
// Вручную, без цикла, найдите сумму элементов этого массива.
let arr170 = [[1, 2, 3,   [  4, 5,   [6, 7]  ]],    [8,  [9, 10]]    ]; 
console.log(arr170[0][0] + arr170[0][1] + arr170[0][2] + arr170[0][3][0] + arr170[0][3][1] + arr170[0][3][2][0] + arr170[0][3][2][1] + arr170[1][0] + arr170[1][1][0] + arr170[1][1][1] )

// 171 Перебор многомерных массивов в JavaScript
// С помощью вложенных циклов найдите сумму элементов этого массива.
let arr171 = [[1, 2, 3], [4, 5], [6]];
let sum171 = 0;
for (let subArr171 of arr171) {
	for (let elem171 of subArr171) {
    sum171 += elem171;
		
	}
}
console.log(sum171);

// С помощью вложенных циклов найдите сумму элементов этого массива.
let arr171_2 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
let sum171_2 = 0;
for (let subArr171_2 of arr171_2) {
	for (let elem171_2 of subArr171_2) {
    for (let e171_2 of elem171_2)
    sum171_2 += e171_2;
		
	}
}
console.log(sum171_2);

// 173 Заполнение многомерных массивов JavaScript
// Сформируйте с помощью двух вложенных циклов следующий массив:
let arr173 = [];
for (let i173 = 0; i173 < 5; i173++) {
	arr173[i173] = []; 
	for (let j173 = 0; j173 < 5; j173++) {
		arr173[i173].push(j173 + 1); 
	}
}
console.log(arr173);

// Сформируйте с помощью трех вложенных циклов следующий массив:
let arr173_3 = [];
for(let i173_3 = 0; i173_3 < 3; i173_3++) {
arr173_3[i173_3] = [];

 for(let j173_3 = 0; j173_3 < 2; j173_3++) {
 arr173_3[i173_3].push([]);

  for(let k173_3 = 0; k173_3 < 5; k173_3++) {
  arr173_3[i173_3][j173_3][k173_3] = k173_3+1;
  }
 }
}
console.log(arr173_3)

// 175 Заполнение многомерных массивов по порядку в JavaScript
// Сформируйте с помощью двух вложенных циклов следующий массив:
let start175 = 2;
let result175 = [];
for (let i175 = 0; i175 < 4; i175++) {
  let row175 = [];
  for (let j175 = 0; j175 < 3; j175++) {
    row175.push(start175);
    start175 += 2;
  }
  result175.push(row175);
}
console.log(result175);

// 176 Многомерные объекты в JavaScript
// Найдите сумму элементов приведенного объекта.
let obj176 = {
	key1: {
		key1: 1,
		key2: 2,
		key3: 3,
	},
	key2: {
		key1: 4,
		key2: 5,
		key3: 6,
	},
	key3: {
		key1: 7,
		key2: 8,
		key3: 9,
	},
}
console.log(obj176.key1.key1+obj176.key1.key2+obj176.key1.key3+obj176.key2.key1+obj176.key2.key2+obj176.key2.key3+obj176.key3.key1+obj176.key3.key2+obj176.key3.key3)

// 177 Перебор многомерных объектов в JavaScript
// Используя циклы, найдите сумму элементов этого объекта.
let obj177 = {
	1: {
		1: 11,
		2: 12,
		3: 13,
	},
	2: {
		1: 21,
		2: 22,
		3: 23,
	},
	3: {
		1: 24,
		2: 25,
		3: 26,
	},
}
let sum177 = 0;
for (let key177 in obj177) {
	let subObj177 = obj177[key177];
	
	for (let subKey177 in subObj177) {
	    sum177 += subObj177[subKey177];
	}
}
	console.log(sum177);

// 178 Многомерные структуры в JavaScript
// Выведите на экран первого студента из третьей группы.
let students178 = {
	'group1': ['name11', 'name12', 'name13'],
	'group2': ['name21', 'name22', 'name23'],
	'group3': ['name31', 'name32', 'name33'],
};
console.log(students178['group3'][0]);

// 179 Перебор многомерных структур JavaScript
// С помощью вложенных циклов выведите на экран все строки с данными.
let data179 = {
	1: [
		'data11',
		'data12',
		'data13',
	],
	2: [
		'data21',
		'data22',
		'data23',
	],
	3: [
		'data31',
		'data32',
		'data33',
	],
	4: [
		'data41',
		'data42',
		'data43',
	],
};
for (let num179 in data179) {
	for (let value179 of data179[num179]) {
		console.log(value179);
	}
}

// 180 Массив объектов в JavaScript
// Выведите на экран данные каждого работника в формате имя - зарплата.
let employees180 = [
	{
		name: 'name1',
		salary: 300,
	},
	{
		name: 'name2',
		salary: 400,
	},
	{
		name: 'name3',
		salary: 500,
	},
];

for (let employee180 of employees180) {
	console.log(employee180.name + ' ' + employee180.salary);
}

// Выведите на экран сумму зарплат всех работников.
let employees180_2 = [
	{
		name: 'name1',
		salary: 300,
	},
	{
		name: 'name2',
		salary: 400,
	},
	{
		name: 'name3',
		salary: 500,
	},
];
let sum180 = 0;
for (let employee180_2 of employees180_2) {
    sum180 += employee180_2.salary;
    
}
	console.log(sum180);

// 181 Ключи из переменных в многомерных структурах JavaScript
// Пусть даны также три переменные, содержащие год, месяц и день. Выведите дело, соответствующее значениям переменных.
let affairs181 = {
	'2018': {
		11: {
			29: ['дело111', 'дело112', 'дело113'],
			30: ['дело121', 'дело122', 'дело123'],
		},
		12: {
			30: ['дело211', 'дело212', 'дело213'],
			31: ['дело221', 'дело222', 'дело223'],
		},
	},
	'2019': {
		12: {
			29: ['дело311', 'дело312', 'дело313'],
			30: ['дело321', 'дело322', 'дело323'],
			31: ['дело331', 'дело332', 'дело333'],
		}
	},
}
let year181 = '2019';
let month181 = 12;
let day181 = 31;
console.log(affairs181[year181][month181][day181]);

// 182 Добавление элементов в многомерные массивы JavaScript
// Добавьте в следующий массив еще одного работника:
let employees182 = [
	{
		name: 'name1',
		salary: 300,
		age: 28,
	},
	{
		name: 'name2',
		salary: 400,
		age: 29,
	},
	{
		name: 'name3',
		salary: 500,
		age: 30,
	},
];
employees182.push({
	name: 'name4',
	salary: 600,
    age: 31,
});

// 183 Добавление элементов в многомерные объекты JavaScript
// Добавьте еще одно дело в дату '2019-12-29'. Добавьте еще два дела в дату '2019-12-31'.
let affairs183 = {
	'l20191228': ['data11', 'data12', 'data13'],
	'l20191229': ['data21', 'data22', 'data23'],
	'l20191230': ['data31', 'data32', 'data33'],
}
affairs183.l20191231 = [];
affairs183.l20191229.push('data24');
affairs183.l20191231.push('data41','data42');
console.log(affairs183)

// 184 Степень и корень в JavaScript
console.log(Math.pow(2, 10));
console.log(Math.sqrt(245));

// 185 Функции округления в JavaScript
// Найдите квадратный корень из 379. Результат округлите до целых, до десятых, до сотых.
let a185 = Math.sqrt(379);
console.log(Math.round(a185));
console.log(a185.toFixed(1));
console.log(a185.toFixed(2));

// Найдите квадратный корень из 587. Округлите результат в большую и меньшую стороны, запишите результаты округления в объект с ключами 'floor' и 'ceil'.
let b185 = Math.sqrt(587);
console.log(b185);
console.log(Math.floor(b185));
console.log(Math.ceil(b185));

// 186 Экстремальные числа в JavaScript
// Даны числа 4, -2, 5, 19, -130, 0, 10. Найдите минимальное и максимальное число.
console.log(Math.max(4, -2, 5, 19, -130, 0, 10));
console.log(Math.min(4, -2, 5, 19, -130, 0, 10));

// 187 Рандом в JavaScript
// Выведите на экран случайное целое число от 1 до 100.
function getRandomInt187(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

console.log(getRandomInt187(1, 100));
 
// 188 Модули в JavaScript
// Даны переменные a и b. Найдите модуль разности a и b. Проверьте работу скрипта самостоятельно для различных a и b.
let a188 = -10;
let b188 = 10;
let c188 = a188-b188;
console.log(Math.abs(c188));

// 189 Регистр символов в JavaScript
let a189 = 'js';
let b189 = 'JS';
console.log(a189.toUpperCase());
console.log(b189.toLowerCase());

// 190 Вырезание строк в в JavaScript
// Дана строка 'я учу javascript!'. Вырежьте из нее слово 'учу' и слово 'javascript' тремя разными способами (через substr, substring, slice).
let str190 = 'я учу javascript!';
let a190 = str190.substr(2, 3);
let b190 = str190.substring(2,5);
let c190 = str190.slice(6,16)
console.log(a190,b190, c190);

// 191 Поиск по строкам в JavaScript
// Дана строка. Проверьте, начинается ли эта строка на 'http://'.
let str191 = 'http:// я учу javascript!';
let res191 = str191.startsWith('http://');
console.log(res191);

// let str191_2 = 'http:// я учу javascript! .html';
let res191_2 = str191.endsWith('.html');
console.log(res191_2);

// 192 Замена частей строки в JavaScript
// Дана строка '1-2-3-4-5'. Поменяйте все дефисы на точки.
let elem192 = '-';
let str192 = '1-2-3-4-5';

while (str192.includes(elem192)) {
	str192 = str192.replace(elem192, '.');
}
console.log(str192)

// 193 Части строк в JavaScript
// Дана строка '1-2-3-4-5'. С помощью метода split запишите каждое число этой строки в отдельный элемент массива.
let str193 = '1-2-3-4-5';
let arr193 = str193.split('-');

console.log(arr193);

// 194 Граничные элементы в JavaScript
// Добавьте ему в начало и конец элементы 4, 5, 6.
let arr194 = [1,2,3];
arr194.push(4,5,6);
arr194.unshift(4,5,6);
console.log(arr194);

// 195 Части массивов в JavaScript
/* Дан следующий массив:

[1, 2, 3, 4, 5]
Сделайте из этого массива следующий:
[1, 2, 3] */
let arr195 = [1, 2, 3, 4, 5]
let sub195 = arr195.slice(0, 3);
console.log(sub195);

// 196 Вырезание массивов в JavaScript
/* Дан следующий массив:

[1, 2, 3, 4, 5]
С помощью метода splice сделайте из него массив:

[1, 2, 3, 'a', 'b', 'c', 4, 5] */
let arr196 = [1, 2, 3, 4, 5]
arr196.splice(3,0,'a', 'b', 'c');
console.log(arr196);

// 197 Поиск по массивам в JavaScript
// Проверьте, есть ли в этом массиве число 3.
let arr197 = [1, 2, 3, 4, 5];
let res197 = arr197.includes(3);
console.log(res197);

// 198 Массив ключей объекта в JavaScript
// Получите массив ключей объекта.
let obj198 = {'a': 1, 'b': 2, 'c': 3};
console.log(Object.keys(obj198));

// 199 Поиск ошибок в коде со стандартными методами JavaScript
/* Код должен найти сумму цифр числа:

let num = 12345;
let arr = String(num).split('');
let sum = 0;
for (let digit of arr) {
	sum += Number(digit);
}
console.log(sum); // почему-то выводит 5, а не 15


Код должен найти сумму цифр числа:
let num = 12345;
let arr = String(num).split('');
let sum = 0;
for (let digit of arr) {
	sum += Number(digit);
}
console.log(sum);


Код должен найти произведение цифр числа:
let num = 12345;
let arr = String(num).split('');
let prod = 1;
for (let digit of arr) {
	prod *= digit;
}
console.log(prod);
*/




