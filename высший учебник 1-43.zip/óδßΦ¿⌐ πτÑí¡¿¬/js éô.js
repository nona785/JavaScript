// Стилизация через атрибут style в JavaScript
let elem = document.querySelector('#elem1');
elem.style.color = 'red';
console.log(elem.style.color); 

// 2 Единицы измерения в атрибуте style в JavaScript
// Дан див и кнопка. По нажатию на кнопку задайте диву ширину в 400px, а высоту в 300px.
let elem2 = document.querySelector('#elem2');
let but2 = document.querySelector('#but2');
but2.addEventListener('click',()=>{
    elem2.style.width = '400px';
    elem2.style.height = '300px';
});

// 4 Распаковка значений CSS свойств в JavaScript
// Дан див. Дана также кнопка. По клику на кнопку выведите толщину границы, ее тип и цвет.
let elem4 = document.querySelector('#elem4');
let but4 = document.querySelector('#but4');
but4.addEventListener('click',()=>{
    console.log(elem4.style.borderWidth, elem4.style.borderStyle, elem4.style.borderColor);
});

// 5 Сброс стилей через style в JavaScript
// Дан див и две кнопки. По клику на первую кнопку спрячьте див, а по клику на вторую - покажите.
let elem5 = document.querySelector('#elem5');
let but5 = document.querySelector('#but5');
let but05 = document.querySelector('#but05');
but5.addEventListener('click',()=>{
    elem5.style.display = 'none';
});
but05.addEventListener('click',()=>{
    elem5.style.display = '';
});

// Дан див и две кнопки. По клику на первую кнопку покрасьте цвет дива в красный цвет, а по клику на вторую - верните исходный цвет.
let elem5_2 = document.querySelector('#elem5_2');
let but5_2 = document.querySelector('#but5_2');
let but0_5 = document.querySelector('#but0_5');
but5_2.addEventListener('click',()=>{
    elem5_2.style.color = 'red';
});
but0_5.addEventListener('click',()=>{
    elem5_2.style.color = '';
});

// 8 Чтение свойств из CSS файлов в JavaScript
// По клику на кнопку выведите ширину и высоту элемента.
let elem8 = document.querySelector('#elem8');
let but8 = document.querySelector('#but8');
let computedStyle8 = getComputedStyle(elem8);
but8.addEventListener('click',()=>{
    console.log(computedStyle8.width,computedStyle8.height);
});

// 10 Стилизация классами в JavaScript
// Даны абзацы с числами. Переберите эти абзацы циклом и абзацы, содержащие четные числа, покарасьте в красный цвет, а содержащие нечетные - в зеленый.
let paragraph10 = document.querySelectorAll('#p10');
paragraph10.forEach(function(paragraph10) {
  let number = parseInt(paragraph10.textContent); 
  if (number % 2 === 0) {
    paragraph10.classList.add('even'); 
  } else {
    paragraph10.classList.add('odd');
  }
});

// 11 Один класс для стилизации в JavaScript
// Даны абзацы. Сделайте так, чтобы каждый абзац по первому клику на него красился в красный цвет, а по второму клику - красился обратно в черный.
let paragraph11 = document.querySelectorAll('#p11');
paragraph11.forEach(function(paragraph11) {
  let clickCount = 0;
  paragraph11.addEventListener('click', function() {
    clickCount++;
    if (clickCount % 2 === 1) {
      paragraph11.style.color = 'red'; 
    } else {
      paragraph11.style.color = 'black'; 
    }
  });
});

// 12 Неудобство классов в JavaScript
// Дан инпут. По потери фокуса проверьте, что в него введено не более 9-ти символов. Если это так, покрасьте границу инпута в зеленый цвет, а если не так - в красный.
let elem12 = document.querySelector('#input12');
elem12.addEventListener('blur', ()=>{
    if (elem12.value.length <= 9) {
        elem12.classList.add('nine');
    }
    else {
        elem12.classList.add('notnine');
    }
});

// 13 Чередование стилей через data- атрибут в JavaScript
// Дан инпут. По потери фокуса проверьте введенное в него число. Если это число до десяти, то покрасьте инпут в зеленый цвет, если от десяти до двадцати - в желтый, а если более двадцати - в красный.
let elem13 = document.querySelector('#input13');
elem13.addEventListener('blur', ()=>{
    if (elem13.value < 10) {
        elem13.classList.add('green');
    }
    else if (elem13.value >= 10 && elem13.value <= 20)  {
        elem13.classList.add('yellow');
    } else if (elem13.value > 20) {
        elem13.classList.add('red');
    }
});

// 16 Клиентский размер элемента в JavaScript
let elem16 = document.querySelector('#elem');
let button = document.getElementById("button");
button.addEventListener("click", function() {
     console.log(elem16.clientWidth);
     console.log(elem16.clientHeight);
 });

// 17 Полный размер элемента в JavaScript
button.addEventListener("click", function() {
     console.log(elem16.offsetWidth);
     console.log(elem16.offsetHeight);
 });
// 17.2 
button.addEventListener("click", function() {
    console.log(elem16.offsetWidt - elem.clientWidth);
    console.log(elem16.offsetHeight - elem.clientHeight);
});

// 18 Размеры элемента с прокруткой в JavaScript
button.addEventListener("click", function() {
    console.log(elem16.scrollWidth);
    console.log(elem16.scrollHeight);
});
// 18.2 
button.addEventListener("click", function() {
    console.log(elem16.scrollWidth - elem.offsetWidth);
    console.log(elem16.scrollHeight - elem.offsetHeight);
});

// 19 Прокрутка элементов в JavaScript
function getTotalScrollHeight() {
    return elem16.scrollHeight;
}
// 19.2
button.addEventListener("click", function() {
    if (elem16.scrollTop > 0) {
        console.log("Прокручивается");
    } else {
        console.log("Не прокручивается");
    }
});
// 19.3
button.addEventListener("click", function() {
    console.log(getTotalScrollHeight());
});
// 19.4
function getTotalScrollHeight() {
    return elem16.scrollHeight;
}
button.addEventListener("click", function() {
    console.log(elem16.scrollHeight - getTotalScrollHeight());
});
// 19.5
function getTotalScrollHeight() {
    return elem16.scrollHeight;
}
button.addEventListener("click", function() {
    console.log(elem16.scrollHeight - (elem16.offsetHeight + getTotalScrollHeight()));
});

// 20 Изменение прокрутки элемента в JavaScript
button.addEventListener("click", function() {
    elem16.scrollTop = 100;
    elem16.scrollLeft = 50;
});
// 20.2 
button.addEventListener("click", function() {
    elem16.scrollTop = elem16.scrollTop + 50;
});
// 20.3 
button.addEventListener("click", function() {
    elem16.scrollTop = elem16.scrollTop - elem16.scrollTop;
});
// 20.4 
button.addEventListener("click", function() {
    elem16.scrollTop = elem16.scrollHeight;
});

// 21 Прокрутка элемента до конца в JavaScript
button.addEventListener("click", function() {
    elem16.scrollTop = elem16.scrollHeight - elem16.clientHeight;
});
// 21.2
button.addEventListener('click', function() {
    if (elem16.scrollTop === elem16.scrollHeight - elem16.clientHeight) {
    alert('Элемент прокручен до конца');
    } else {
    alert('Элемент не прокручен до конца');
    }
    });

// 22 Распахивание элемента в JavaScript
button.addEventListener("click", function() {
    elem16.style.height = elem16.scrollHeight + 'px';
});

// 24 Размеры окна в JavaScript
function showSize() {
  alert('Ширина окна:' + window.innerWidth, 'Высота окна:' + window.innerHeight);
}
function checkVerticalScroll() {
  if (document.documentElement.clientHeight < window.innerHeight) {
    alert('Вертикальная прокрутка присутствует');
  } else {
    alert('Вертикальная прокрутка отсутствует');
  }
}
function checkHorizontalScroll() {
  if (document.documentElement.clientWidth < window.innerWidth) {
    alert('Горизонтальная прокрутка присутствует');
  } else {
    alert('Горизонтальная прокрутка отсутствует');
  }
}

// 25 Размеры окна с учетом прокрутки в JavaScript
function showHeightWithScroll() {
let scrollHeight = Math.max(
document.body.scrollHeight, document.documentElement.scrollHeight,
document.body.offsetHeight, document.documentElement.offsetHeight,
document.body.clientHeight, document.documentElement.clientHeight
);
alert('высота с учетом прокрученной части:' + scrollHeight);
}
function showWidthWithScroll() {
let scrollWidth = Math.max(
document.body.scrollWidth, document.documentElement.scrollWidth,
document.body.offsetWidth, document.documentElement.offsetWidth,
document.body.clientWidth, document.documentElement.clientWidth
);
alert('ширина с учетом прокрученной части:' + scrollWidth);
}
function showHiddenHeight() {
let hiddenHeight = document.body.scrollHeight - window.innerHeight;
alert('высота спрятанная под прокруткой:' + hiddenHeight);
}

// 26 Получение прокрутки окна в JavaScript
function showVerticalScroll() {
let yOffset = window.pageYOffset;
alert('прокручено окно по вертикали:' + yOffset);
}
function showRemainingScroll() {
let remainingScroll = document.body.scrollHeight - window.innerHeight - window.pageYOffset;
alert('осталось до конца прокрутки по вертикали:' + remainingScroll);
}

// 27 Получение и изменение прокрутки окна в JavaScript
function scrollToPosition(position) {
document.documentElement.scrollTop = position;
}
function scrollToTop() {
document.documentElement.scrollTop = 0;
}
function scrollToBottom() {
document.documentElement.scrollTop = document.body.scrollHeight - window.innerHeight;
}

// 28 Метод для прокрутки окна в положение в JavaScript
function scrollToPosition(position) {
window.scrollTo({
top: position,
behavior: 'auto'
});
}
function scrollToTop() {
window.scrollTo({
top: 0,
behavior: 'smooth'
});
}
function scrollToBottom() {
window.scrollTo({
top: document.body.scrollHeight,
behavior: 'smooth'
});
}

// 29 Метод для прокрутки окна на величину в JavaScript
function scrollByPosition(x, y) {
window.scrollBy(x, y);
}
function smoothScrollByPosition(x, y) {
window.scrollBy({
top: y,
left: x,
behavior: 'smooth'
});
}

// 30 Метод для прокрутки окна к элементу в JavaScript
function scrollToElement() {
let element = document.getElementById('scrollToElement');
element.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'end' });
}

// 31 Событие прокрутки в JavaScript
window.addEventListener('scroll', function() {
  console.log(window.pageYOffset);
  if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
    let message = document.createElement('div');
    message.textContent = 'Вы достигли конца страницы!';
    document.body.appendChild(message);
  }
});
  
// 32 Коллекции Map в JavaScript
// Пусть даны 3 массива. Создайте коллекцию Map, сделайте ключами коллекции эти массивы, а значениями - какие-нибудь строки.
let array1 = [1, 2, 3];
let array2 = ['a', 'b', 'c'];
let array3 = ['x', 'y', 'z'];
let map1 = new Map();
map1.set(array1, 'String 1');
map1.set(array2, 'String 2');
map1.set(array3, 'String 3');

// Пусть даны 3 объекта и 3 массива. Создайте коллекцию Map, сделайте ключами коллекции объекты, а значениями - соответствующие массивы.
let obj1 = {name: 'Alice'};
let obj2 = {name: 'Bob'};
let obj3 = {name: 'Charlie'};
let arr1 = [10, 20, 30];
let arr2 = [100, 200, 300];
let arr3 = [1000, 2000, 3000];
let map2 = new Map();
map2.set(obj1, arr1);
map2.set(obj2, arr2);
map2.set(obj3, arr3);

// 35 Ключи и значения в коллекциях Map
// Пусть дана коллекция Map. Получите массив ее ключей и переберите их циклом for-of.
for (let key of map1.keys()) {
    console.log(key);
}
// Пусть дана коллекция Map. Получите массив ее элементов и переберите их циклом for-of.
for (let entry of map1.entries()) {
    console.log(entry);
}

// 36 Применение коллекций Map
// Даны инпуты. Переберите эти инпуты циклом и создайте коллекцию Map, ключами в которой будут инпуты, а значением - их порядковый номер на странице. Сделайте так, чтобы по клику на любой инпут ему в value записывался его порядковый номер.
let inputs36 = document.querySelectorAll('#input36');
let inputMap = new Map();
inputs36.forEach((input36, index) => {
    inputMap.set(input36, index + 1);
    input36.addEventListener('click', () => {
        input36.value = inputMap.get(input36);
    });
});
// Даны инпуты. В каждый инпут можно ввести число. Пусть по нажатию на Enter инпут запоминает введенное число. Сделайте так, чтобы по потери фокуса в инпуте в консоль выводился массив всех введенных ранее в инпут чисел.
let inputs362 = document.querySelectorAll('#input36_2');
let numbersArray = [];
inputs362.forEach(input362 => {
    input362.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
            numbersArray.push(Number(input362.value));
        }
    });
    input362.addEventListener('blur', function() {
        console.log(numbersArray);
    });
});

// 37 Коллекции Set в JavaScript
// Создайте коллекцию Set. С помощью метода add добавьте в нее элементы. Убедитесь, что дубли элементов не добавляются.
let set37 = new Set;
set37.add(1);
set37.add(2);
set37.add(3);
set37.add(3); 

// 38 Начальное заполнение коллекции Set в JavaScript
// С помощью этого массива создайте коллекцию Set.
let arr38 = [1, 2, 3, 1, 3, 4];
let set38 = new Set(arr38);
console.log(set38);
// Создайте коллекцию Set с начальными значениями 1, 2 и 3. С помощью метода add добавьте в коллекцию еще одно число 2. Выведите содержимое коллекции в консоль, убедитесь, что число 2 не добавилось второй раз.
let set1 = new Set([1, 2, 3]);
set1.add(2);
console.log(set1);

// 39 Полезные возможности коллекций Set
// Создайте коллекцию Set с начальными значениями 1, 2 и 3. Выведите на экран количество элементов в коллекции.
let set2 = new Set([1, 2, 3]);
console.log(set2.size);
// Создайте коллекцию Set с начальными значениями 1, 2 и 3. Проверьте наличие в коллекции элемента со значением 3, а затем элемента со значением 4.
let set3 = new Set([1, 2, 3]);
console.log(set3.has(3));
console.log(set3.has(4));

// 40 Перебор коллекций Set циклом
// Создайте коллекцию Set с какими-нибудь числами. Переберите эту коллекцию циклом и найдите сумму ее элементов.
let set4 = new Set([1, 2, 3, 4, 5]);
let sum40 = 0;
for (let num of set4) {
    sum40 += num;
}
console.log(sum40);

// 42 Удаление дублей из массива через Set
// Напишите функцию, которая параметром будет принимать массив и возвращать этот массив без дублей.
function removeDuplicates(array) {
    return Array.from(new Set(array));
}

// 43 Получение DOM элементов без дублей
// Даны абзацы и кнопка. Пользователь кликает на эти абзацы в произвольном порядке. Сделайте так, чтобы по нажатию на кнопку в конец каждого абзаца, на который был совершен клик, был добавлен восклицательный знак.
let paragraphs = document.querySelectorAll('#p43');
let button43 = document.querySelector('#button43');
paragraphs.forEach(paragraph => {
    paragraph.addEventListener('click', () => {
        paragraph.textContent += '!';
    });
});
button43.addEventListener('click', () => {
    paragraphs.forEach(paragraph => {
        paragraph.textContent += '!';
    });
});