// 279 Метод map для перебора массива в JavaScript
// Дан массив с числами. Используя метод map извлеките из каждого элемента массива квадратный корень и запишите результат в новый массив.
let arr79 = [1, 2, 3, 4, 5];
let res79 = arr79.map(function(elem79) {
	return elem79 ** 2;
});
console.log(res79);

// Дан массив со строками. Используя метод map в конец значению каждого элемента массива добавьте символ '!'.
let arr792 = ['a', 'b', 'c', 'd', 'e'];
let res792 = arr792.map(function(elem792) {
	return elem792+'!';
});
console.log(res792);

// Дан массив с числами. Используя метод map запишите в каждый элемент массива значение этого элемента, умноженное на его порядковый номер в массиве.
let result79 = arr79.map(function(elem79, index79) {
	return elem79 * index79;
});
console.log(result79);

// 280 Метод forEach для перебора массива в JavaScript
// Дан массив с числами. Используя метод forEach найдите сумму квадратов элементов этого массива.
let arr80 = [1, 2, 3, 4, 5];
let sum80 = 0;
arr80.forEach(function(elem80) {
        sum80+=elem80**2;
});
console.log(sum80)

// 281 Метод filter для фильтрации массива в JavaScript
// Дан массив с числами. Оставьте в нем только положительные числа.
let arr81 = [-1, 1, -3, 4, 10];
let res81 = arr81.filter(function(elem81) {
	if (elem81 >= 0) {
		return true;
	} else {
		return false;
	}
});
console.log(res81);

// Дан массив с числами. Оставьте в нем только числа, которые больше нуля, но меньше 10.
let arr812 = [-1, 1, -3, 4, 10];
let res812 = arr812.filter(function(elem812) {
	if (elem812 > 0 && elem812 < 10) {
		return true;
	} else {
		return false;
	}
});
console.log(res812);

// Дан массив со строками. Оставьте в нем только те строки, длина которых больше 5-ти символов.
let arr813 = ['abcde','abcdef','abc','acndjcnsi'];
let res813 = arr813.filter(function(elem813) {
	if (elem813.length > 5) {
		return true;
	} else {
		return false;
	}
});

console.log(res813);

// 282 Метод every для проверки массива в JavaScript
// Дан массив с числами. Проверьте то, что все элементы в массиве больше нуля.
let arr82 = [1, 2, 3, 0, 4, 5];
let check82 = arr82.every(function(elem82) {
	if (elem82 > 0) {
		return true;
	} else {
		return false;
	}
});
console.log(check82);

// 283 Метод some для проверки массива в JavaScript
// Дан массив с числами. Проверьте то, что в массиве есть хотя бы одно число больше нуля.
let arr83 = [2, 4, 6, 8];

let result83 = arr83.some(function(elem83) {
	return elem83 > 0;
});

console.log(result83);

// 286 Оператор spread в JavaScript
// Найдите с помощью приведенной функции сумму элементов массива.
let arr86 = [1, 2, 3, 4, 5];
function func(num1, num2, num3, num4, num5) {
	return num1 + num2 + num3 + num4 + num5;
}
console.log(func(... arr86))

// 288 Экстремальные значения массива через spread в JavaScript
// Дан массив с числами. Используя Math.min и spread выведите на экран минимальное значение массива.
let arr88 = [1, 2, 3, 4, 5];
console.log(Math.min(... arr88))

// 293 Функция, находящая сумму чисел с помощью операторов rest и spread в JavaScript
// Напишите функцию, которая будет принимать параметрами произвольное количество чисел и возвращать их среднее арифметическое.
function func(...nums93) {
	let sum93 = 0;
	let kol93 = 0;
	for (let num93 of nums93) {
		sum93 += num93;
		kol93+=1;
	}
	return sum93/kol93;
}
let result93 = func(1, 2, 3, 4);
console.log(result93);

// 296 Деструктуризация массивов в JavaScript
// Переделайте этот код через деструктуризацию согласно изученной теории.
let arr96 = ['John', 'Smit', 'development', 'programmer', 2000];
let [name96, surname96, department96, position96, salary96] = arr96;
console.log(name96+' '+surname96+' '+department96+' '+position96+' '+salary96);

// 297 Деструктуризация массива из функции в JavaScript
// Переделайте этот код через деструктуризацию согласно изученной теории.
function func97() {
	return ['John', 'Smit', 'development', 'programmer', 2000];
}
let [name97, surname97, department97, position97, salary97] = func97();
console.log(name97+' '+surname97+' '+department97+' '+position97+' '+salary97)

// 298 Пропуск элементов массива при деструктуризации в JavaScript
// Переделайте этот код через деструктуризацию согласно изученной теории.
let arr98 = ['John', 'Smit', 'development', 'programmer', 2000];
let [name98, , , position98, ] = arr98;
console.log(name98+' '+position98)

// 300 Остаток массива при деструктуризации в JavaScript
// Переделайте этот код через деструктуризацию согласно изученной теории.
let arr00 = ['John', 'Smit', 'development', 'programmer', 2000];
let [name00, surname00, ...salary00] = arr00;
console.log(salary00)

// 304 Деструктуризация объектов в JavaScript
// Переделайте этот код через деструктуризацию согласно изученной теории.
let options4 = {
	color: 'red',
	width:  400,
	height: 500,
};
let {color,width,height} = options4;
console.log(color+' '+width+' '+height);

// 305 Имена переменных при деструктуризации объектов в JavaScript
// Переделайте этот код через деструктуризацию согласно изученной теории.
let options5 = {
	color5: 'red',
	width5:  400,
	height5: 500,
};
let {color5: c5, width5: w5, height5: h5} = options5;
console.log(c5+' '+w5+' '+h5)

// 311 Работа с объектом Date в JavaScript
// 1) Выведите на экран текущий день.
let date11 = new Date();
console.log(date11.getDate());

// 2) Выведите на экран текущий месяц.
console.log(date11.getMonth());

// 3) Выведите на экран текущий год.
console.log(date11.getFullYear());

// 312 Форматирование даты в JavaScript
// Выведите на экран текущую дату-время в формате 12:59:59 31.12.2014. Используйте для всех частей даты (кроме года) созданную нами функцию для добавления нуля при необходимости.
let date12 = new Date();
console.log(date12.getHours()+':'+date12.getMinutes()+':'+date12.getSeconds()+' '+date12.getFullYear() + '.' + date12.getMonth() + 1 + '.' + date12.getDate());

// 313 Смена формата даты в JavaScript
// Дана дата в формате год-месяц-день. Преобразуйте эту дату в формат день.месяц.год.
let str13 = '2025-12-31';
let res13 = str13.split('-').reverse().join('.');
console.log(res13);

// 314 Получения дня недели на JavaScript
// Выведите на экран номер текущего дня недели.
let date14 = new Date();
let a14 = date14.getDay();
// Определите, является ли текущий день недели выходным или рабочим днем.
switch(a14) {
    case 0:  
        console.log('выходной :)');
        break;
    case 1:  
        console.log('рабочий :(');
        break;
    case 2:  
        console.log('рабочий :(');
        break;
    case 3:  
        console.log('рабочий :(');
        break;
    case 4:  
        console.log('рабочий :(');
        break;
    case 5:  
        console.log('рабочий :(');
        break;
    case 6:  
        console.log('выходной :)');
        break;
    default: ;
}

// 315 Вывод частей даты словом в JavaScript
// Выведите с помощью массива название текущего месяца.
// Выведите с помощью этого массива название текущего месяца.
let date15 = new Date();
let now15  = date15.getMonth();
let months15 = [
	'янв', 'фев', 'мар', 'апр', 'май', 'июн',
	'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'
];

console.log(months15[now15]);

// 316 Установка времени в объекте Date в JavaScript
// Узнайте, какой день недели был в ваш день рождения.
let date16 = new Date(2025, 3, 23); 
let day16  = date16.getDay();
let days16 = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб','вс'];
console.log(days16[day16]);

// 317 Получение времени в формате timestamp в JavaScript
// Выведите на экран timestamp, соответствующий дате 1 января 2025 года.
let date17 = new Date(2025, 1, 1, 23, 59, 59);
console.log(date17.getTime());

// 318 Разность между датами в формате timestamp в JavaScript
// Выведите на экран количество дней, прошедшее между 1 марта 1988 года и 10 января 2000 года.
let d1  = new Date(1988, 3, 1, 23, 59, 59);
let d2 = new Date(2000, 1, 10, 23, 59, 59);
let diff318 = d2.getTime() - d1.getTime();
console.log((diff318 / (1000 * 60 * 60)/24));

// 319 Разница между объектами с датой в JavaScript
// Выведите на экран количество миллисекунд, прошедшее между 1 сентября 2000 года и 15 февраля 2010 года.
let d191  = new Date(2000, 9, 1, 12, 59, 59);
let d192 = new Date(2010, 2, 15, 12, 59, 59);
let diff19 = d192 - d191;
console.log(diff19);
// Модифицируйте предыдущую задачу так, чтобы на экран выводилась разница в днях.
console.log(diff19/ (1000 * 60 * 60)/24);

// 322 Определение високосного года в JavaScript
// Сделайте функцию isLeap, которая параметром будет принимать год и возвращать true, если этого год високосный, и false - если нет.
function isLeap(year) {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

// 324 Получение дня текущего года в JavaScript
// Определите, какой день недели будет 31 декабря текущего года.
const today24 = new Date();
const now24 = today24.getFullYear();
const lastDay24 = new Date(now24, 11, 31);
const days24 = ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"];
console.log(days24[lastDay24.getDay()]);

// 325 День следующего или предыдущего месяца
// Определите, какой день недели был месяц назад в такой же день месяца, как сегодня.
const today25 = new Date();
const last25 = new Date(today25.getFullYear(), today25.getMonth() - 1, today25.getDate());
const days25 = ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"];
console.log(days25[last25.getDay()]);

// 326 День следующего или предыдущего года
// Определите, какой день недели будет 31 декабря следующего года.
const today26 = new Date();
const next26 = today26.getFullYear() + 1;
const last26 = new Date(next26, 11, 31);
const days26 = ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"];
console.log(days26[last26.getDay()]);
// Определите, какой день недели будет через год в такую же дату, как сегодня.
const today262 = new Date();
const next262 = today262.getFullYear() + 1;
const same262 = new Date(next262, today262.getMonth(), today262.getDate());
console.log(days26[same262.getDay()]);

// 327 Разность моментов
// Определите, сколько дней между 1 января и 10 сентября текущего года.
let d271 = new Date(2024, 1, 1, 12, 59, 59);
let d272 = new Date(2024, 9, 10, 12, 59, 59);
let razn27 = d272 - d271;
console.log(razn27 / (1000 * 60 * 60)/24); 

// 328 Момент времени дня
// Определите, сколько часов прошло между вчерашним полднем и текущим моментом времени.
let now28  = new Date();
let date28 = new Date(now28.getFullYear(), now28.getMonth(), now28.getDate() - 1, 12);
console.log(Math.round((now28-date28)/ 3600000))

// 329 Начало дня в JavaScript
// Определите, сколько часов прошло между началом дня и текущим моментом времени.
let now29  = new Date();
let date29 = new Date(now29.getFullYear(), now29.getMonth(), now29.getDate());
console.log(Math.round((now29-date29)/ 3600000))

// 330 Конец дня в JavaScript
// Определите, сколько часов осталось до конца дня.
let now30  = new Date();
let date30 = new Date(now30.getFullYear(), now30.getMonth(), now30.getDate(), 23, 59, 59);
console.log(Math.round((date30-now30)/ 3600000))

// 332 Практика на получение моментов времени в JavaScript
// Определите, сколько секунд прошло с начала дня до настоящего момента времени.
console.log(Math.round((now29-date29)/ 1000))
// Определите, сколько секунд осталось до конца дня.
console.log(Math.round((date30-now30)/ 1000))
// Определите, сколько дней осталось до нового года.
let neww = new Date(2024, 2, 25, 12, 59, 59);
let newYear = new Date(2025, 1, 1, 12, 59, 59);
let razn = newYear - neww;
console.log(Math.round(razn / (1000 * 60 * 60)/24)); 
// Определите, какой год был 3 месяца назад.
const now1 = new Date();
const threeMonthsAgo = new Date(now1.getFullYear(), now1.getMonth() - 3, now1.getDate());
console.log('год, который был 3 месяца назад: ', threeMonthsAgo.getFullYear());
// Определите, какой день недели будет в последнем дне текущего месяца.
const now2 = new Date();
const lastDayOfMonth = new Date(now2.getFullYear(), now2.getMonth() + 1, 0);
const dayOfWeek = lastDayOfMonth.getDay();
const daysOfWeek = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
console.log('День недели в последнем дне текущего месяца: ', daysOfWeek[dayOfWeek]);
// Напишите код, который будет определять, високосный ли текущий год.
const now3 = new Date();
const year = now3.getFullYear();
const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
if (isLeapYear) {
    console.log('год является високосным');
} else {
    console.log('год не является високосным');
}

// 333 Строковое сравнение дат на JavaScript
// Напишите код, который сравнит две приведенные ниже даты и выведет сообщение о том, какая из них больше:
let date33 = '2020-11-31';
let date332 = '2020-12-01';
if (date33 > date332) {
    console.log('первая дата больше');
} else {
        console.log('вторая дата больше');
}

// 334 Сравнение даты без года в JavaScript
// Напишите код, который сравнит две приведенные ниже даты и выведет сообщение о том, какая из них больше:
let date34 = '09-21';
let date342 = '09-23';
if (date34 > date342) {
    console.log('первая дата больше');
} else {
        console.log('вторая дата больше');
}

// 336 Сравнение объектов с датами в JavaScript
// Получите объект с датой, содержащий текущий момент времени. Получите объект с датой, содержащий полдень текущего дня. Сравните два этих объекта и определите, был ли уже полдень или нет.
let now36  = new Date();
let noon36 = new Date(2024, 2, 25, 12, 59, 59);
if (noon36 > now36) {
    console.log('полдень уже прошел')
} else {
    console.log('полдень еще не настал')
}
// Получите объект с датой, содержащий текущий момент времени. Получите объект с датой, содержащий 15 число текущего месяца. Сравните два этих объекта и определите, прошла ли уже половина месяца или нет.
const now362 = new Date();
const half362 = new Date(now362.getFullYear(), now362.getMonth(), 15);
if (now362.getDate() >= 15) {
    console.log('половина месяца уже прошла');
} else {
    console.log('половина месяца еще не прошла');
}






