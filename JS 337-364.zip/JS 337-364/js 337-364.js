// 339 Получение DOM элемента в JavaScript
// Запишите ссылку на каждый из абзацев в отдельную переменную и выведите содержимое каждой из этих переменных в консоль.
let first39 = document.querySelector('#elem1');
console.log(first39);
let second39 = document.querySelector('#elem2');
console.log(second39);
let third39 = document.querySelector('#elem3');
console.log(third39);

// 340 Сложные селекторы DOM элемента в JavaScript
// Получите ссылку на первый абзац из дива с id, равным block.
let elem40 = document.querySelector('#block');
console.log(elem40);
// Получите ссылку на первый абзац из дива с классом block.
let elem402 = document.querySelector('.block');
console.log(elem402);
// Получите ссылку на первый абзац с классом www.
let elem403 = document.querySelector('.www');
console.log(elem403);

// 341 Привязывание обработчиков к элементам в JavaScript
// Сделайте так, чтобы по клику на первую кнопку на экран выводилось число 1, по клику на вторую - число 2, а по клику на третью - число 3.
let button41 = document.querySelector('#button1');
button41.addEventListener('click', ()=>{
    console.log(1);
})
let button412 = document.querySelector('#button2');
button412.addEventListener('click', ()=>{
    console.log(2);
})
let button413 = document.querySelector('#button3');
button413.addEventListener('click', ()=>{
    console.log(3);
})

// 342 Именованные обработчики событий в JavaScript
// Даны следующие функции:
function func1() {
	console.log(1);
}
function func2() {
	console.log(2);
}
// Сделайте так, чтобы по клику на первую кнопку выполнилась функция func1, а по клику на вторую - функция func2.
let button421 = document.querySelector('#button421');
button421.addEventListener('click', func1);
let button422 = document.querySelector('#button422');
button422.addEventListener('click', func2);

// 343
// Один обработчик ко многим элементам в JavaScript
// Дана следующая функция:
function func43() {
	console.log('message');
}
//  Привяжите эту функцию ко всем 5-ти абзацам.
let f43 = document.querySelector('#elem431');
let s43 = document.querySelector('#elem432');
let t43 = document.querySelector('#elem433');
let fo43 = document.querySelector('#elem434');
let fif43 = document.querySelector('#elem435');
f43.addEventListener('click', func43);
s43.addEventListener('click', func43);
t43.addEventListener('click', func43);
fo43.addEventListener('click', func43);
fif43.addEventListener('click', func43);

// 344 Несколько обработчиков одного события в JavaScript
// Даны следующие функции:
function func441() {
	console.log('1');
}
function func442() {
	console.log('2');
}
function func443() {
	console.log('3');
}
// Привяжите все эти функции к нашему абзацу.
let elem44 = document.querySelector('#elem44');
elem44.addEventListener('click', func441);
elem44.addEventListener('click', func442);
elem44.addEventListener('click', func443);

// 345 Обработчики разных событий в JavaScript
// Дана кнопка. По двойному клику по ней выведите какое-нибудь сообщение.
let elem45 = document.querySelector('#button45');
elem45.addEventListener('dblclick', ()=>{
    console.log(':)');
});
// Дана кнопка. По наведению на нее выведите какое-нибудь сообщение.
let elem452 = document.querySelector('#button452')
elem452.addEventListener('mouseover', ()=>{
    console.log('ай');
})
// Дана кнопка. По уходу курсора с нее выведите какое-нибудь сообщение.
let elem453 = document.querySelector('#button453');
elem453.addEventListener('mouseout', ()=>{
    console.log('пока :)');
})
// Дана кнопка. По наведению на нее выведите одно сообщение, а по уходу с нее - другое.
function f45() {
    console.log('привет :)');
}
function f451() {
    console.log('пока :(');
}
let elem454 = document.querySelector('#button454');
elem454.addEventListener('mouseover', f45);
elem454.addEventListener('mouseout', f451);

// 346 Работа с текстом элементов на JavaScript
// Дан абзац и кнопка. По клику на кнопку прочитайте текст абзаца и выведите его в консоль.
let elem46 = document.querySelector('#elem46');
let but46 = document.querySelector('#button46');
but46.addEventListener('click', ()=>{
    console.log(elem46.textContent);
});
// Даны два абзаца, содержащие своим текстом какие-то числа, и кнопка. По нажатию на кнопку выведите на экран сумму хранящихся чисел.
let elem462 = document.querySelector('#elem462');
let but462 = document.querySelector('#button462');
let elem4620 = document.querySelector('#elem4620');
but462.addEventListener('click', ()=>{
    console.log(Number(elem462.textContent) + Number(elem4620.textContent));
}); 
// Дан абзац с текстом и кнопка. По нажатию на кнопку запишите в конец текста абзаца восклицательный знак.
let elem463 = document.querySelector('#elem463');
let but463 = document.querySelector('#button463');
but463.addEventListener('click', ()=>{
    console.log(elem463.textContent+'!');
})

// 347 Работа с HTML кодом элементов на JavaScript
// Дан абзац и кнопка. По клику на кнопку прочитайте HTML код абзаца и выведите его в консоль.
let elem47 = document.querySelector('#elem47');
let but47 = document.querySelector('#button47');
but47.addEventListener('click', ()=>{
    console.log(elem47.innerHTML);
})
// Дан абзац и кнопка. По клику на кнопку запишите в абзац новый текст так, чтобы он был жирным.
let elem472 = document.querySelector('#elem472');
let but472 = document.querySelector('#button472');
but472.addEventListener('click', ()=>{
    console.log(elem47.textContent);
})

// 348 Атрибуты тегов как свойства в JavaScript
// По нажатию на кнопку выведите на экран содержимое атрибута type указанного выше инпута.
let elem48 = document.querySelector('#elem48');
elem48.addEventListener('click', ()=>{
    console.log(elem48.type);
})
// Пусть у вас есть ссылка в виде тега a, кнопка и абзац. По нажатию на кнопку выведите в абзац содержимое атрибута href ссылки.
let elem482 = document.querySelector('#elem48');
let but48 = document.querySelector('#button482');
let a48 = document.querySelector('#ss');
but48.addEventListener('click', ()=>{
    console.log(a48.href);
})
// По нажатию на кнопку запишите в атрибут type значение submit.
let elem481 = document.querySelector('#elem481');
let but481 = document.querySelector('#button481');
but481.addEventListener('click', ()=>{
    elem481.type = 'submit';
    console.log(elem481.type);
});
// Пусть у вас есть ссылка и кнопка. По нажатию на кнопку добавьте в конец текста ссылки содержимое ее атрибута href в круглых скобках.
let a483 = document.querySelector('#s48');
let but483 = document.querySelector('#button483');
but483.addEventListener('click', ()=>{
    console.log(a483.textContent +'('+a483.href+')');
});
// Дана картинка в теге img и кнопка. По нажатию на кнопку в атрибут width запишите значение 300.
let minion = document.querySelector('#minion');
let but484 = document.querySelector('#button484');
but484.addEventListener('click', ()=>{
    minion.width = '300';
});
// Дана картинка в теге img и кнопка. Пусть в атрибуте width задана некоторая ширина. Сделайте кнопку, по нажатию на которую ширина картинки будет увеличиваться в 2 раза.
let minion1 = document.querySelector('#minion1');
let but485 = document.querySelector('#button485');
but485.addEventListener('click', ()=>{
    minion1.width *= 2;
});

// 349 Работа с текстовыми полями в JavaScript
// Дан инпут и кнопка. По нажатию на кнопку запишите в инпут какой-нибудь текст.
let inp49 = document.querySelector('#elem49');
let but49 = document.querySelector('#button49');
but49.addEventListener('click', ()=>{
    inp49.value = 'это текстовое поле';
});
// Дан инпут, абзац и кнопка. По нажатию на кнопку запишите в абзац текст из инпута.
let inp491 = document.querySelector('#elem491');
let but491 = document.querySelector('#button491');
let p49 = document.querySelector('#abzac49');
but491.addEventListener('click', ()=>{
    p49.textContent = inp491.value;
});
// Даны два инпута и кнопка. В первый инпут пользователем вводится число. По нажатию на кнопку запишите во второй инпут квадрат введенного числа.
let inp492 = document.querySelector('#elem492');
let inp493 = document.querySelector('#elem493');
let but492 = document.querySelector('#button492');
but492.addEventListener('click', ()=>{
    inp493.value = inp492.value**2;
});
// Даны два инпута и кнопка. По нажатию на кнопку запишите в первый инпут значение второго инпута, а во второй инпут - значение первого. Ваш код должен работать универсально, для любых значений инпутов.
let inp494 = document.querySelector('#elem494');
let inp495 = document.querySelector('#elem495');
let but493 = document.querySelector('#button493');
but493.addEventListener('click', ()=>{
    let a;
    a = inp494.value;
    inp494.value = inp495.value;
    inp495.value = a;
});

// 350 Фокус текстовых полей в JavaScript
// Дан инпут. По получению фокуса запишите в него число 1, а по потери фокуса - число 2.
let elem50 = document.querySelector('#elem50');
elem50.addEventListener('focus', ()=>{
    console.log(1);
});
elem50.addEventListener('blur', ()=>{
    console.log(2);
});
// Дан инпут. Пусть в него вводится число. По потери фокуса выведите на экран квадрат этого числа.
let elem501 = document.querySelector('#elem501');
elem501.addEventListener('blur', ()=>{
    elem501.value **=2;
});
// Дан инпут, в котором изначально есть какой-то текст. По получению фокуса инпутом очистите содержимое этого инпута.
let elem502 = document.querySelector('#elem502');
elem502.addEventListener('blur', ()=>{
    elem502.value = '';
});

// 351 Исключения при работе с атрибутами в JavaScript
// По нажатию на кнопку прочитайте и выведите на экран значение атрибута class нашего дива.
let elem51 = document.querySelector('#elem51');
let but51 = document.querySelector('#button51');
let p51 = document.querySelector('#id51');
but51.addEventListener('click', ()=>{
    p51.textContent = elem51.className;
});

// 352 Цепочки методов и свойств в JavaScript
/* Дан следующий код:
<img id="image" src="avatar.png">
let image = document.querySelector('#image');
console.log(image.src);
Переделайте приведенный выше код так, чтобы вместо введения переменной image использовалась цепочка.
console.log(document.querySelector('#image').src); */

// 354 Объект this в JavaScript
// Дан инпут. По получению фокуса этим инпутом запишите в него число 1, а по потери фокуса - число 2. Для обращения у инпуту внутри функции-обработчика используйте объект this.
let elem54 = document.querySelector('#elem54');
elem54.addEventListener('focus', function() {
    this.value = 1;
});
elem54.addEventListener('blur', function() {
    this.value = 2;
});
// Дана кнопка, значением которой служит число 1. Сделайте так, чтобы по клику на эту кнопку ее значение каждый раз увеличивалось на единицу.
let but54 = document.querySelector('#button54');
but54.addEventListener('click', function() {
    this.value ++;
})

// 355 Преимущество this в JavaScript
// Даны 5 абзацев с какими-то текстами. По клику на любой абзац запишите в конец его текста восклицательный знак.
let a55 = document.querySelector('#id55');
let a551 = document.querySelector('#id551');
let a552 = document.querySelector('#id552');
let a553 = document.querySelector('#id553');
let a554 = document.querySelector('#id554');
a55.addEventListener('click', func55);
a551.addEventListener('click', func55);
a552.addEventListener('click', func55);
a553.addEventListener('click', func55);
a554.addEventListener('click', func55);
function func55() {
    this.textContent += '!';
}
// Даны 3 инпута, в которых записаны какие-то числа. По потери фокуса в любом из инпутов возведите стоящее в нем число в квадрат.
let e551 = document.querySelector('#elem55_1');
let e552 = document.querySelector('#elem55_2');
let e553 = document.querySelector('#elem55_3');
e551.addEventListener('blur', func552);
e552.addEventListener('blur', func552);
e553.addEventListener('blur', func552);
function func552() {
    this.value **= 2;
}

// 356 Получение группы элементов в JavaScript
// Даны абзацы и кнопка. По нажатию на кнопку найдите все абзацы, переберите их циклом и установите текст каждого абзаца в значение 'text'.
let elems55 = document.querySelectorAll('#id56');
let but56 = document.querySelector('#button56');
but56.addEventListener('click', ()=>{
    for (let elem55 of elems55) {
        elem55.textContent += 'text';
    }
});
// Даны инпуты с числами, абзац и кнопка. По нажатию на кнопку найдите сумму чисел из инпутов и запишите эту сумму в текст абзаца.
let elems56 = document.querySelectorAll('#elem56');
let p56 = document.querySelector('#id562');
let but562 = document.querySelector('#button562');
but562.addEventListener('click', ()=>{
    let sum56 = 0;
    for (let elem56 of elems56) {
        sum56 += Number(elem56.value);
    }
    p56.textContent = sum56;
})

// 357 Добавление обработчиков в цикле в JavaScript
// Сделайте так, чтобы по потери фокуса в любом из наших инпутов выполнялась приведенная выше функция.
let elems57 = document.querySelectorAll('#elem57');

for (let elem of elems57) {
	elem.addEventListener('blur', func57);
}
function func57() {
	this.value = Number(this.value) + 1;
}

// 359 Отвязывание событий в JavaScript
// Дана кнопка, значением которой служит число 1. Сделайте так, чтобы по клику на эту кнопку ее значение каждый раз увеличивалось на единицу. После того, как значение кнопки достигнет 10 - отвяжите обработчик события, чтобы кнопка больше не реагировала на нажатие.
let but59 = document.querySelector('#button59');
but59.addEventListener('click', () => {
    if (but59.value < 10) {
        but59.value++;
    } else {
        but59.removeEventListener('click');
    }
});

// 360 Отвязывание обработчиков событий в цикле в JavaScript
// Даны абзацы. По нажатию на любой из абзацев добавьте ему в конец восклицательный знак. Сделайте так, чтобы это добавление происходило лишь по первому нажатию.
let elems60 = document.querySelectorAll('#id60');
for (let elem60 of elems60) {
	elem60.addEventListener('click', func60);
}
function func60() {
	this.textContent += '!';
	this.removeEventListener('click', func60); 
}

// 361 Отвязывание анонимных функций в JavaScript
// Дан список ul, в каждом пункте которого записано число. Сделайте так, чтобы по клику на любую li ее число увеличивалось на единицу.
let elems61 = document.querySelectorAll('#spisok61');
for (let elem61 of elems61) {
	elem61.addEventListener('click', func61);
}
function func61() {
	this.textContent = Number(this.textContent)+1;
}
// Модифицируйте предыдущую задачу так, чтобы каждая li увеличивала свое значение только по первому нажатию на нее.
// this.removeEventListener('click', func61);

// 364 Отработка изученного материала на работу с DOM
// Дан инпут и абзац. По потери фокуса в инпуте запишите значение инпута в конец текста абзаца:
/* <input type="text" id="input1">
<p id="paragraph1">Текст в абзаце: </p>

const input1 = document.querySelector('#input1');
const paragraph1 = document.querySelector('#paragraph1');
input1.addEventListener('blur', function() {
    paragraph1.textContent += input1.value;
});

// Дано несколько инпутов, абзац и кнопка. По нажатию на кнопку получите числа, стоящие в этих инпутах и запишите их сумму в абзац:
<input type="text" class="inputNumber">
<input type="text" class="inputNumber">
<input type="text" class="inputNumber">
<button id="calculateSum">Посчитать сумму</button>
<p id="sumResult">Сумма: </p>

const inputNumbers = document.querySelectorAll('.inputNumber');
const calculateSumBtn = document.querySelector('#calculateSum');
const sumResult = document.querySelector('#sumResult');
calculateSumBtn.addEventListener('click', function() {
    let sum = 0;
    inputNumbers.forEach(input => {
        sum += parseInt(input.value) || 0;
    });
    sumResult.textContent = 'Сумма: ' + sum;
});

// Дан инпут. В него вводится число. По потери фокуса найдите сумму цифр этого числа:
<input type="text" id="numberInput">
<p id="sumDigits">Сумма цифр: </p>

const numberInput = document.querySelector('#numberInput');
const sumDigits = document.querySelector('#sumDigits');
numberInput.addEventListener('blur', function() {
    const number = numberInput.value;
    let sum = 0;
    for (let digit of number) {
        sum += parseInt(digit);
    }
    sumDigits.textContent = 'Сумма цифр: ' + sum;
});

// Дан инпут. В него вводятся числа через запятую. По потери фокуса найдите среднее арифметическое этих чисел 
const numbersInput = document.querySelector('#numbersInput');
const averageResult = document.querySelector('#averageResult');

numbersInput.addEventListener('blur', function() {
    const numbers = numbersInput.value.split(',').map(num => parseFloat(num));
    const sum = numbers.reduce((acc, curr) => acc + curr, 0);
    const average = sum / numbers.length || 0;
    averageResult.textContent = 'Среднее арифметическое: ' + average.toFixed(2);
});

// Даны 4 инпута. В первый инпут вводится ФИО через пробел. По потери фокуса запишите фамилию, имя и отчество в остальные 3 инпута:
<input type="text" id="fullNameInput">
<input type="text" id="lastNameInput">
<input type="text" id="firstNameInput">
<input type="text" id="middleNameInput">

const fullNameInput = document.querySelector('#fullNameInput');
const lastNameInput = document.querySelector('#lastNameInput');
const firstNameInput = document.querySelector('#firstNameInput');
const middleNameInput = document.querySelector('#middleNameInput');
fullNameInput.addEventListener('blur', function() {
    const [lastName, firstName, middleName] = fullNameInput.value.split(' ');
    lastNameInput.value = lastName || '';
    firstNameInput.value = firstName || '';
    middleNameInput.value = middleName || '';
});

// Дан инпут. В него вводится слово. По нажатию на кнопку проверьте то, что это слово читается с начала и с конца одинаково (например, мадам):
<input type="text" id="wordInput">
<button id="checkPalindromeBtn">Проверить</button>

const wordInput = document.querySelector('#wordInput');
const checkPalindromeBtn = document.querySelector('#checkPalindromeBtn');
checkPalindromeBtn.addEventListener('click', function() {
    const word = wordInput.value.toLowerCase();
    const reversedWord = word.split('').reverse().join('');
    if (word === reversedWord) {
        alert('Слово является палиндромом!');
    } else {
        alert('Слово не является палиндромом.');
    }
});

// Дан инпут. В него вводится число. Проверьте по потери фокуса, что это число содержит внутри себя цифру 3:
<input type="text" id="numberInput">

const numberInput = document.querySelector('#numberInput');
numberInput.addEventListener('blur', function() {
    const number = numberInput.value;
    if (number.includes('3')) {
        alert('Число содержит цифру 3.');
    } else {
        alert('Число не содержит цифру 3.');
    }
});

// Дан инпут. Даны абзацы. Пусть в этот инпут записывается суммарное количество нажатий по этим абзацам:
<input type="text" id="clickCountInput">
<p>Абзац 1</p>
<p>Абзац 2</p>
<p>Абзац 3</p>

const clickCountInput = document.querySelector('#clickCountInput');
const paragraphs = document.querySelectorAll('p');
let clickCount = 0;
paragraphs.forEach(paragraph => {
    paragraph.addEventListener('click', function() {
        clickCount++;
        clickCountInput.value = clickCount;
    });
});

// Дан инпут и кнопка. По нажатию на кнопку сгенерируйте случайную строку из 8-ми символов и запишите в инпут:
<input type="text" id="randomStringInput">
<button id="generateRandomStringBtn">Сгенерировать</button>

const randomStringInput = document.querySelector('#randomStringInput');
const generateRandomStringBtn = document.querySelector('#generateRandomStringBtn');
generateRandomStringBtn.addEventListener('click', function() {
    const randomString = Math.random().toString(36).substr(2, 8);
    randomStringInput.value = randomString;
});

// Дан инпут и кнопка. Пользователь вводит в инпут какую-то строку. По нажатию на кнопку перемешайте введенные символы случайным образом и запишите ее обратно в инпут:
<input type="text" id="shuffleInput">
<button id="shuffleStringBtn">Перемешать</button>

const shuffleInput = document.querySelector('#shuffleInput');
const shuffleStringBtn = document.querySelector('#shuffleStringBtn');
shuffleStringBtn.addEventListener('click', function() {
    const inputString = shuffleInput.value;
    const shuffledString = inputString.split('').sort(() => 0.5 - Math.random()).join('');
    shuffleInput.value = shuffledString;
});

// Дан инпут, кнопка и абзац. В инпут вводится число. По нажатию на кнопку выведите в абзац факториал этого числа:
<input type="text" id="numberInput">
<button id="factorialBtn">Вычислить факториал</button>
<p id="factorialOutput"></p>

const numberInput = document.querySelector('#numberInput');
const factorialBtn = document.querySelector('#factorialBtn');
const factorialOutput = document.querySelector('#factorialOutput');
function factorial(num) {
    if (num === 0 || num === 1) {
        return 1;
    } else {
        return num * factorial(num - 1);
    }
}
factorialBtn.addEventListener('click', function() {
    const number = parseInt(numberInput.value);
    const result = factorial(number);
    factorialOutput.textContent = Факториал числа ${number}: ${result};
});







